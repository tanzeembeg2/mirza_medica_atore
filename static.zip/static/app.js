﻿const state = {
  medicines: [],
  billItems: [],
  suggestionIndex: -1,
  customers: [],
  users: [],
  profile: null,
};

const money = (value) => Number(value || 0).toFixed(2);
const byId = (id) => document.getElementById(id);
const toast = (message) => window.alert(message);

async function fetchJson(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(`${url}: ${data.message || response.statusText || "Request failed"}`);
  }
  return data;
}

function bindGlobalShortcuts() {
  document.addEventListener("keydown", (event) => {
    if (event.key === "F2") {
      event.preventDefault();
      window.location.href = "/billing";
      return;
    }
    if (event.key === "F4") {
      event.preventDefault();
      window.location.href = "/inventory";
      return;
    }
    if (event.key === "F6") {
      event.preventDefault();
      window.location.href = "/reports";
      return;
    }
    if (event.key === "F8") {
      event.preventDefault();
      window.location.href = "/settings";
      return;
    }

    if (event.ctrlKey && event.key.toLowerCase() === "m") {
      const medicineSearch = byId("medicineSearch");
      if (medicineSearch) {
        event.preventDefault();
        medicineSearch.focus();
        medicineSearch.select?.();
      }
      return;
    }

    if (event.ctrlKey && event.key.toLowerCase() === "i") {
      const inventorySearch = byId("inventorySearch");
      if (inventorySearch) {
        event.preventDefault();
        inventorySearch.focus();
        inventorySearch.select?.();
      }
    }
  });
}

async function initDashboard() {
  const stats = await fetchJson("/api/dashboard");
  document.querySelectorAll("[data-stat]").forEach((node) => {
    const key = node.dataset.stat;
    node.textContent = key.includes("Sales") || key.includes("Value") ? money(stats[key]) : stats[key];
  });

  const labels = stats.salesChart.map((point) => point.label);
  const values = stats.salesChart.map((point) => point.amount);
  const ctx = byId("salesChart");
  if (!ctx) return;

  new Chart(ctx, {
    type: "line",
    data: {
      labels,
      datasets: [
        {
          label: "Sales",
          data: values,
          borderColor: "#155e4b",
          backgroundColor: "rgba(21, 94, 75, 0.12)",
          fill: true,
          tension: 0.35,
        },
      ],
    },
    options: {
      plugins: { legend: { display: false } },
      scales: { x: { grid: { display: false } }, y: { beginAtZero: true } },
    },
  });
}

async function loadMedicines(search = "") {
  const query = search ? `?q=${encodeURIComponent(search)}` : "";
  state.medicines = await fetchJson(`/api/medicines${query}`);
  return state.medicines;
}

function billTotals() {
  return state.billItems.reduce(
    (acc, item) => {
      const gross = item.quantity * item.price;
      const discount = gross * (item.discount_percent / 100);
      const taxable = gross - discount;
      const gst = taxable * (item.gst_percent / 100);
      const total = taxable + gst;
      acc.gross += gross;
      acc.discount += discount;
      acc.gst += gst;
      acc.net += total;
      item.line_total = Number(total.toFixed(2));
      return acc;
    },
    { gross: 0, discount: 0, gst: 0, net: 0 }
  );
}

function renderBillTable() {
  const tbody = byId("billItems");
  if (!tbody) return;

  if (!state.billItems.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty-state">Search medicine and press Enter to add items to the bill.</td></tr>';
  } else {
    tbody.innerHTML = state.billItems
      .map(
        (item, index) => `
          <tr>
            <td><strong>${item.name}</strong><br><small class="muted">${item.code}</small></td>
            <td><input type="number" min="1" value="${item.quantity}" data-type="qty" data-index="${index}"></td>
            <td>${money(item.price)}</td>
            <td>${item.gst_percent}%</td>
            <td><input type="number" min="0" max="100" value="${item.discount_percent}" data-type="discount" data-index="${index}"></td>
            <td>${money(item.line_total)}</td>
            <td class="no-print"><button class="mini-btn" data-action="remove" data-index="${index}" type="button">Remove</button></td>
          </tr>`
      )
      .join("");
  }

  const totals = billTotals();
  byId("grossTotal").textContent = money(totals.gross);
  byId("gstTotal").textContent = money(totals.gst);
  byId("discountTotal").textContent = money(totals.discount);
  byId("netTotal").textContent = money(totals.net);
}

function renderSuggestions(filtered) {
  const box = byId("suggestionBox");
  if (!box) return;
  state.suggestionIndex = filtered.length ? 0 : -1;
  box.innerHTML = filtered
    .map(
      (item, index) => `
        <button type="button" class="suggestion-item ${index === 0 ? "active" : ""}" data-suggest-index="${index}">
          <strong>${item.name}</strong>
          <small class="muted">${item.code} · Qty ${item.quantity} · Rs ${money(item.selling_price)}</small>
        </button>`
    )
    .join("");
}

function addMedicineToBill(medicine) {
  const existing = state.billItems.find((item) => item.medicine_id === medicine.id);
  if (existing) {
    existing.quantity += 1;
  } else {
    state.billItems.push({
      medicine_id: medicine.id,
      code: medicine.code,
      name: medicine.name,
      quantity: 1,
      price: Number(medicine.selling_price),
      gst_percent: Number(medicine.gst_percent || 0),
      discount_percent: 0,
      line_total: Number(medicine.selling_price),
    });
  }
  renderBillTable();
}

async function loadProfile() {
  state.profile = await fetchJson("/api/profile");
  return state.profile;
}

async function initBilling() {
  try {
    await loadMedicines();
    let profile = null;
    try {
      profile = await loadProfile();
    } catch (error) {
      console.warn(error);
    }
    if (profile?.pharmacy) {
      byId("printPharmacyName").textContent = profile.pharmacy.name;
      if (byId("printPharmacyAddress")) {
        byId("printPharmacyAddress").textContent = profile.pharmacy.address || "Gopamau Hardoi, 241404";
      }
    }

    const search = byId("medicineSearch");
    const suggestionBox = byId("suggestionBox");

    const refreshSuggestions = async () => {
      const query = search.value.trim();
      const medicines = await loadMedicines(query);
      renderSuggestions(medicines.slice(0, 8));
    };

    search.addEventListener("input", refreshSuggestions);
    search.addEventListener("focus", refreshSuggestions);
    search.addEventListener("keydown", (event) => {
      const buttons = [...suggestionBox.querySelectorAll("[data-suggest-index]")];
      if (!buttons.length) return;

      if (event.key === "ArrowDown") {
        event.preventDefault();
        state.suggestionIndex = (state.suggestionIndex + 1) % buttons.length;
      }
      if (event.key === "ArrowUp") {
        event.preventDefault();
        state.suggestionIndex = (state.suggestionIndex - 1 + buttons.length) % buttons.length;
      }
      if (event.key === "Enter") {
        event.preventDefault();
        const selected = state.medicines[state.suggestionIndex] || state.medicines[0];
        if (selected) {
          addMedicineToBill(selected);
          suggestionBox.innerHTML = "";
          search.value = "";
        }
      }

      buttons.forEach((button, index) => button.classList.toggle("active", index === state.suggestionIndex));
    });

    suggestionBox.addEventListener("click", (event) => {
      const target = event.target.closest("[data-suggest-index]");
      if (!target) return;
      const item = state.medicines[Number(target.dataset.suggestIndex)];
      if (!item) return;
      addMedicineToBill(item);
      suggestionBox.innerHTML = "";
      search.value = "";
      search.focus();
    });

    byId("billItems").addEventListener("input", (event) => {
      const index = Number(event.target.dataset.index);
      const item = state.billItems[index];
      if (!item) return;
      if (event.target.dataset.type === "qty") item.quantity = Math.max(1, Number(event.target.value || 1));
      if (event.target.dataset.type === "discount") item.discount_percent = Math.max(0, Number(event.target.value || 0));
      renderBillTable();
    });

    byId("billItems").addEventListener("click", (event) => {
      const target = event.target.closest("[data-action='remove']");
      if (!target) return;
      state.billItems.splice(Number(target.dataset.index), 1);
      renderBillTable();
    });

    byId("newBillBtn").addEventListener("click", () => {
      state.billItems = [];
      byId("customerName").value = "Walk-in Customer";
      renderBillTable();
      search.focus();
    });

    byId("saveBillBtn").addEventListener("click", async () => {
      const totals = billTotals();
      const payload = {
        customer_name: byId("customerName").value.trim() || "Walk-in Customer",
        payment_mode: byId("paymentMode").value,
        gross_total: totals.gross,
        gst_total: totals.gst,
        discount_total: totals.discount,
        net_total: totals.net,
        items: state.billItems,
      };
      const result = await fetchJson("/api/sales", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      toast(`Bill saved successfully. Bill No: ${result.bill_no}`);
      state.billItems = [];
      renderBillTable();
      search.focus();
    });

    byId("printBillBtn").addEventListener("click", () => window.print());

    document.addEventListener("keydown", (event) => {
      if (event.ctrlKey && event.key.toLowerCase() === "f") {
        event.preventDefault();
        search.focus();
      }
      if (event.ctrlKey && event.key.toLowerCase() === "s") {
        event.preventDefault();
        byId("saveBillBtn").click();
      }
      if (event.ctrlKey && event.key.toLowerCase() === "p") {
        event.preventDefault();
        byId("printBillBtn").click();
      }
    });

    renderBillTable();
  } catch (error) {
    console.error(error);
    toast(`Billing load error: ${error.message}`);
  }
}

function medicinePayloadFromForm() {
  return {
    name: byId("name").value.trim(),
    category: byId("category").value.trim(),
    expiry_date: byId("expiry_date").value,
    supplier: byId("supplier").value.trim(),
    unit: byId("unit").value.trim() || "Strip",
    rack: byId("rack").value.trim(),
    quantity: Number(byId("quantity").value || 0),
    min_stock: Number(byId("min_stock").value || 0),
    purchase_price: Number(byId("purchase_price").value || 0),
    mrp: Number(byId("mrp").value || 0),
    selling_price: Number(byId("selling_price").value || 0),
    gst_percent: Number(byId("gst_percent").value || 0),
  };
}

function fillMedicineForm(item) {
  byId("medicineId").value = item?.id || "";
  byId("name").value = item?.name || "";
  byId("category").value = item?.category || "";
  byId("expiry_date").value = item?.expiry_date || "";
  byId("supplier").value = item?.supplier || "";
  byId("unit").value = item?.unit || "Strip";
  byId("rack").value = item?.rack || "";
  byId("quantity").value = item?.quantity || 0;
  byId("min_stock").value = item?.min_stock || 10;
  byId("purchase_price").value = item?.purchase_price || 0;
  byId("mrp").value = item?.mrp || item?.selling_price || 0;
  byId("selling_price").value = item?.selling_price || 0;
  byId("gst_percent").value = item?.gst_percent || 5;
}

function inventoryRowBadges(item) {
  if (item.quantity <= item.min_stock) return '<span class="badge danger">Low stock</span>';
  if (item.expiry_date && new Date(item.expiry_date) <= new Date(Date.now() + 90 * 24 * 60 * 60 * 1000)) return '<span class="badge warn">Expiring</span>';
  return '<span class="badge">Healthy</span>';
}

function renderInventoryTable(items) {
  const tbody = byId("inventoryTable");
  if (!tbody) return;
  tbody.innerHTML = items.length
    ? items
        .map(
          (item) => `
        <tr>
          <td><strong>${item.name}</strong><br><small class="muted">${item.category || item.code}</small></td>
          <td>${item.quantity}</td>
          <td>${money(item.purchase_price)}</td>
          <td>${money(item.mrp || item.selling_price)}</td>
          <td>${money(item.selling_price)}</td>
          <td>${item.supplier || "-"}</td>
          <td>${item.expiry_date || "-"}</td>
          <td>${inventoryRowBadges(item)}</td>
          <td>
            <button class="mini-btn" data-edit-id="${item.id}" type="button">Edit</button>
            <button class="mini-btn" data-delete-id="${item.id}" type="button">Delete</button>
          </td>
        </tr>`
        )
        .join("")
    : '<tr><td colspan="9" class="empty-state">No medicines found.</td></tr>';
}

async function initInventory() {
  const form = byId("inventoryForm");
  const resetBtn = byId("resetMedicineBtn");
  const searchInput = byId("inventorySearch");
  const importInput = byId("excelImportInput");

  const refresh = async (query = "") => {
    const items = await loadMedicines(query);
    renderInventoryTable(items);
  };

  await refresh();

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const id = byId("medicineId").value;
    const payload = medicinePayloadFromForm();
    const url = id ? `/api/medicines/${id}` : "/api/medicines";
    const method = id ? "PUT" : "POST";
    await fetchJson(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    toast(id ? "Medicine updated successfully." : "Medicine added successfully.");
    fillMedicineForm(null);
    await refresh(searchInput.value.trim());
  });

  resetBtn.addEventListener("click", () => fillMedicineForm(null));
  searchInput.addEventListener("input", async () => {
    await refresh(searchInput.value.trim());
  });

  byId("inventoryTable").addEventListener("click", async (event) => {
    const edit = event.target.closest("[data-edit-id]");
    if (edit) {
      const item = state.medicines.find((row) => row.id === Number(edit.dataset.editId));
      if (item) fillMedicineForm(item);
      return;
    }
    const del = event.target.closest("[data-delete-id]");
    if (!del) return;
    if (!window.confirm("Delete this medicine?")) return;
    await fetchJson(`/api/medicines/${del.dataset.deleteId}`, { method: "DELETE" });
    await refresh(searchInput.value.trim());
  });

  importInput.addEventListener("change", async () => {
    const [file] = importInput.files;
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);
    const response = await fetch("/api/import/excel", { method: "POST", body: formData });
    const data = await response.json();
    if (!response.ok) return toast(data.message || "Import failed.");
    toast(data.message);
    importInput.value = "";
    await refresh();
  });
}

async function initCustomers() {
  const form = byId("customerForm");
  const search = byId("customerSearch");
  const refresh = async (query = "") => {
    state.customers = await fetchJson(`/api/customers${query ? `?q=${encodeURIComponent(query)}` : ""}`);
    byId("customerTable").innerHTML = state.customers.length
      ? state.customers
          .map(
            (item) => `
          <tr>
            <td>${item.name}</td>
            <td>${item.phone || "-"}</td>
            <td>${item.address || "-"}</td>
            <td>${new Date(item.created_at).toLocaleDateString()}</td>
          </tr>`
          )
          .join("")
      : '<tr><td colspan="4" class="empty-state">No customers found.</td></tr>';
  };
  await refresh();
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    await fetchJson("/api/customers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: byId("customer_name").value.trim(),
        phone: byId("customer_phone").value.trim(),
        address: byId("customer_address").value.trim(),
      }),
    });
    toast("Customer saved successfully.");
    form.reset();
    await refresh(search.value.trim());
  });
  search.addEventListener("input", async () => refresh(search.value.trim()));
}

async function initReports() {
  const data = await fetchJson("/api/reports");
  byId("reportSalesTable").innerHTML = data.recentSales.length
    ? data.recentSales
        .map(
          (item) => `
        <tr>
          <td>${item.bill_no}</td>
          <td>${item.customer_name}</td>
          <td>${money(item.net_total)}</td>
          <td>${item.payment_mode}</td>
          <td>${new Date(item.created_at).toLocaleString()}</td>
        </tr>`
        )
        .join("")
    : '<tr><td colspan="5" class="empty-state">No sales yet.</td></tr>';

  byId("topItemsTable").innerHTML = data.topItems.length
    ? data.topItems
        .map(
          (item) => `
        <tr>
          <td>${item.medicine_name}</td>
          <td>${item.sold_qty}</td>
          <td>${money(item.revenue)}</td>
        </tr>`
        )
        .join("")
    : '<tr><td colspan="3" class="empty-state">No item movement yet.</td></tr>';
}

function fillProfile(profile) {
  byId("profile_display_name").value = profile.user?.display_name || "";
  byId("profile_username").value = profile.user?.username || "";
  byId("profile_phone").value = profile.user?.phone || "";
  byId("owner_name").value = profile.pharmacy?.owner_name || "";
  byId("pharmacy_name").value = profile.pharmacy?.name || "";
  byId("pharmacy_address").value = profile.pharmacy?.address || "";
  byId("pharmacy_phone").value = profile.pharmacy?.phone || "";
}

function fillManagedUserForm(user = null) {
  byId("managed_user_id").value = user?.id || "";
  byId("managed_display_name").value = user?.display_name || "";
  byId("managed_username").value = user?.username || "";
  byId("managed_username").disabled = false;
  byId("managed_password").value = "";
  byId("managed_phone").value = user?.phone || "";
  byId("managed_role").value = user?.role || "staff";
  byId("managed_active").value = String(user?.active ?? true);
}

function renderUsersTable() {
  const tbody = byId("usersTable");
  if (!tbody) return;
  tbody.innerHTML = state.users.length
    ? state.users
        .map(
          (user) => `
        <tr>
          <td>${user.display_name}</td>
          <td>${user.username}</td>
          <td>${user.role}</td>
          <td>${user.phone || "-"}</td>
          <td>${user.active ? "Active" : "Inactive"}</td>
          <td><button class="mini-btn" data-edit-user="${user.id}" type="button">Edit</button></td>
        </tr>`
        )
        .join("")
    : '<tr><td colspan="6" class="empty-state">No users found.</td></tr>';
}

async function initSettings() {
  const profile = await loadProfile();
  fillProfile(profile);

  byId("profileForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    await fetchJson("/api/profile", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        display_name: byId("profile_display_name").value.trim(),
        username: byId("profile_username").value.trim(),
        phone: byId("profile_phone").value.trim(),
        owner_name: byId("owner_name").value.trim(),
        pharmacy_name: byId("pharmacy_name").value.trim(),
        pharmacy_address: byId("pharmacy_address").value.trim(),
        pharmacy_phone: byId("pharmacy_phone").value.trim(),
      }),
    });
    toast("Profile updated successfully.");
  });

  byId("passwordForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    await fetchJson("/api/change-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        current_password: byId("current_password").value,
        new_password: byId("new_password").value,
      }),
    });
    toast("Password updated successfully.");
    byId("passwordForm").reset();
  });

  try {
    state.users = await fetchJson("/api/users");
  } catch {
    state.users = [];
  }
  renderUsersTable();

  if (!state.users.length) {
    const adminBlock = document.querySelector(".admin-only-block");
    if (adminBlock) adminBlock.style.display = "none";
    return;
  }

  fillManagedUserForm();
  byId("resetUserBtn").addEventListener("click", () => fillManagedUserForm());

  byId("userForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const userId = byId("managed_user_id").value;
    const payload = {
      display_name: byId("managed_display_name").value.trim(),
      username: byId("managed_username").value.trim(),
      password: byId("managed_password").value.trim(),
      phone: byId("managed_phone").value.trim(),
      role: byId("managed_role").value,
      active: byId("managed_active").value === "true",
    };
    const url = userId ? `/api/users/${userId}` : "/api/users";
    const method = userId ? "PUT" : "POST";
    await fetchJson(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    toast(userId ? "User updated successfully." : "User created successfully.");
    state.users = await fetchJson("/api/users");
    renderUsersTable();
    fillManagedUserForm();
  });

  byId("usersTable").addEventListener("click", (event) => {
    const edit = event.target.closest("[data-edit-user]");
    if (!edit) return;
    const user = state.users.find((item) => Number(item.id) === Number(edit.dataset.editUser));
    if (user) fillManagedUserForm(user);
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  bindGlobalShortcuts();
  if (byId("dashboardStats")) await initDashboard();
  const page = document.querySelector("[data-page]")?.dataset.page;
  if (page === "billing") await initBilling();
  if (page === "inventory") await initInventory();
  if (page === "customers") await initCustomers();
  if (page === "reports") await initReports();
  if (page === "settings") await initSettings();
});
